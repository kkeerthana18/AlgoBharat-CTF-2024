require("dotenv").config({ path: __dirname+"/.env" });

export const my_mnemonic = process.env.mnemonic!;
